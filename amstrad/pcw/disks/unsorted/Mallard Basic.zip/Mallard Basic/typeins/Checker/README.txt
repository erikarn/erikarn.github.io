8000 Plus / PCW Plus listings checkers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  Listings published in 8000 Plus from issue 10 onward were printed with a 
four-digit checksum at the end of each line. Periodically, a checksum utility
would be published; running a BASIC listing through this utility would 
generate checksums using the same algorithm. This allowed the user to check
for typing errors made when keying a listing.

  This directory contains the following check utilities:

check1.bas:	The first version of the checker, used in issues 10-25. 
		Output is sent to the printer. The algorithm used is 
		flawed: only six characters of every seven are checked.
check1.c:	A port of CHECK1.BAS to ANSI C.

check2.bas:	The second version of the checker, used in issues 26-42. 
		Corrects the bug in CHECK1; as a consequence, it generates a
		different set of numbers.
check2.c:	A port of CHECK2.BAS to ANSI C.

check3.bas:	The third version, used in issues 43-106. Allows output
		to screen, printer or disc file; the checksum algorithm 
		remains the same, so it can be used interchangeably with 
		CHECK2, and there is no need for a separate ANSI C port.

check5z.rsx:	My own contribution -- a replacement for CHECK2 / CHECK3, which
		runs within Mallard BASIC. This allows programs to be checked
		as you type them, without any need to save them as ASCII and
		switch to a separate program.
check5z.z80:	Z80 source for check5z.rsx
check5z.txt:	Original documentation for check5z.rsx

