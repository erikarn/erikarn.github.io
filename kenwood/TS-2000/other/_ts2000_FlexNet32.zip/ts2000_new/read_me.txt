Unpack the zip, 
Unpack kissinit.zip and install (put) kissinit.ini and kissinit.exe on c:/
Unpack FlexNet32.zip and install somewhere you like 


---- First you need to edit TS2000.bat
-pcom(x) comport number
-b comportspeed (must be the same as in TS2000)


---- Second Edit kissinit.ini at section [TS2000]
-MYCALL
-HBAUD
-TXD


In FlexNet open Parameters, select New Driver, select KISS and edit the KISS driver.
Put the right Port (comport) and Baudrate (comport speed) (same as in TS2000.bat).


---- About the TS2000;
Menu 46 SUB
Menu 47 1200 or 9600 (same as HBAUD!!)
Menu 48 TNC BAND
Menu 55 ON
Menu 56 Comport speed (same as in TS2000.bat and FlexNet)


---- How to run:
Run TS2000.BAT  (( NB You need to run TS2000.bat before FlexNet!!!! ))
Run FlexNet
Run UIview32 (and install for use with FlexNet)
Run NBF packet (install for use with FlexNet)
