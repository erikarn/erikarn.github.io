Helo all - de SP9AUV!

To group KenwoodTS-2000 I uploaded to section FILES 
http://groups.yahoo.com/group/KenwoodTS-2000/files/

Interface_PSK_RTTY_FSK_CW_AUDIO_by_SP9AUV.zip

for TRX/COM with use Eagle 4.1 program. 
Unzip this files with a directory .
This Interface is specially design to 
TS-2000 (separated ground for every signal)
but also me be used to any transceiver.
If you wish you can edit this for 
use yours elements . Then copy all
files what is in a Eagle 4.1 directory 
to your Eagle directories 
This files contains designed by mee 
schematic and board with all needes 
layer to make this project.
Interface working in a all mode :
 -PSK   RTTY  CW   FSK 
   and Audio  for send audio from your 
   computer to TR/X 
Also contain elements library "SP9AUV.lbr" 
for Eagle 4.1 - definied transformer and 
another elements .
Files:  with extension .sch - Schematic  in a Eagle 
        with extension .brd - boards in a Eagle
All files (schematic, board layout)
also is present in a folowing format  
  -  .ps (PostScript)
  -  .cdr (corel Draw 9.0)
  -  .pdf (Adobe Acrobat) or .gif
Board I was do with use iron home method .
Layer is print on paper by laser printer .
Toner from paper is transffered to copper board 
with use hot iron.
Then you can do etching with use ferric chloride.
You can look for iron method on 

http://www.5bears.com/pcb.htm
http://www.infiltec.com/SID-GRB@home/pcb-home.htm
http://www.qsl.net/vk5cu/
The better it is described - but in a polish language
http://www.piotr.nabielec.com/?doc=pasje/elektronika

Look also in a google.com giving CREATE BOARD IRON METHOD

             Vy 73 de Jerzy SP9AUV
