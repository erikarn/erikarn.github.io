TS-2000 Firmware spoof program

This program is provided as is, no waranties, use at your own risk

The purpose of the program is to help those who come across the problem whereby the Kenwood firmware will sometimes not recognise the TS-2000 following a failed update. This program fools the update program into thinking that it has a healthy TS-2000 attached.

Usage is as follows, you need to connect two Com ports back to back using a Null modem cable. Note, you cannot use the normal cable that connects to the TS-2000 as this is a straight through cable, you need a swapover between pins 2 and 3.
Select the comport that you want to use for this program, from the dropdown box and click on the "Open Com Port" button.

Next run the Kenwood software on the other comport. It will see the correct responses and get past the radio detection phase.
You can then attach your real TS-2000 (using the correct cable) to the Kenwood port and continue with your firmware update.

73 Laurie - G6ISY